# FER > 2024-04-27 6:14pm
https://universe.roboflow.com/yolo-onuf0/fer-s4bk3

Provided by a Roboflow user
License: CC BY 4.0

